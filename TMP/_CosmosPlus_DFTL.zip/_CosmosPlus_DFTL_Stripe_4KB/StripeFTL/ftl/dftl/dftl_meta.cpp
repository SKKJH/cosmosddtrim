/*******************************************************
*
* Copyright (C) 2018-2019 
* Embedded Software Laboratory(ESLab), SUNG KYUN KWAN UNIVERSITY
* 
* This file is part of ESLab's Flash memory firmware
* 
* This source can not be copied and/or distributed without the express
* permission of ESLab
*
* Author: DongYoung Seo (dongyoung.seo@gmail.com)
		  Kyuhwa Han (hgh6877@gmail.com)
* ESLab: http://nyx.skku.ac.kr
*
*******************************************************/

#include "dftl_internal.h"

VOID
META_CACHE_ENTRY::Initialize(VOID)
{
	m_nMetaLPN = INVALID_LPN;
	INIT_LIST_HEAD(&m_dlList);
    INIT_LIST_HEAD(&m_dlHash);   //Hash kjh

	m_bValid = FALSE;
	m_bDirty = FALSE;
	m_bIORunning = FALSE;
}

VOID
META_CACHE::Initialize(VOID)
{
	INIT_LIST_HEAD(&m_dlLRU);
	INIT_LIST_HEAD(&m_dlFree);
	m_nFreeCount = 0;

	m_nHit = 0;
	m_nMiss = 0;

// Meta
    for (INT32 i = 0; i < META_HASH_SIZE; ++i)
        INIT_LIST_HEAD(&m_ahHash[i]);
// Hash kjh

	for (INT32 i = 0; i < META_CACHE_ENTRY_COUNT; i++) //META_CACHE_ENTRY_COUNT: 256
	{
		m_astCacheEntry[i].Initialize();

		_Release(&m_astCacheEntry[i]);
	}

	m_nFormatMetaLPN = INVALID_LPN;
}

BOOL
META_CACHE::Format(VOID)
{
	BOOL bRet;

	do
	{
		if (m_nFormatMetaLPN == INVALID_LPN)
		{
			m_nFormatMetaLPN = 0;
		}

		META_L2V_MGR*	pstMetaL2VMgr = DFTL_GLOBAL::GetMetaL2VMgr();
		if (m_nFormatMetaLPN >= pstMetaL2VMgr->GetMetaLPNCount())
		{
			// Format done
			bRet = TRUE;
			break;
		}

		META_CACHE_ENTRY*	pstEntry = _Allocate();
		if (pstEntry == NULL)
		{
			bRet = FALSE;
			break;
		}

		DEBUG_ASSERT(pstEntry->m_bValid == FALSE);
		DEBUG_ASSERT(pstEntry->m_bDirty == FALSE);
		DEBUG_ASSERT(pstEntry->m_bIORunning == FALSE);

		for (INT32 i = 0; i < L2V_PER_META_PAGE; i++)
		{
			pstEntry->m_anL2V[i] = INVALID_LPN; //L2V_PER_META_PAGE = 1024
		}

		pstEntry->m_bDirty = TRUE;
		pstEntry->m_bValid = TRUE;

		pstEntry->m_nMetaLPN = m_nFormatMetaLPN;

		_HashInsert(pstEntry); //Hash KJH

		m_nFormatMetaLPN++;

		bRet = FALSE;

	} while(0);

	return bRet;
}

META_CACHE_ENTRY*
META_CACHE::GetMetaEntry(UINT32 nLPN)
{
	static INT32	nPrevLPN;
	UINT32	nMetaLPN = _GetMetaLPN(nLPN);
    META_CACHE_ENTRY* pstEntry = _HashFind(nMetaLPN);

    if (pstEntry != NULL) {
        list_move_head(&pstEntry->m_dlList, &m_dlLRU);
        DFTL_GLOBAL::GetInstance()->IncreaseProfileCount(PROFILE_L2PCACHE_HIT);
        nPrevLPN = nLPN;
        return pstEntry;
    }

	if (nPrevLPN != nLPN)
	{
		DFTL_GLOBAL::GetInstance()->IncreaseProfileCount(PROFILE_L2PCACHE_MISS);
		nPrevLPN = nLPN;
	}

	return NULL;
}

BOOL
META_CACHE::IsMetaAvailable(UINT32 nLPN)
{
#if (META_PER_WAY==1)
	UINT32 mod_lpn = get_mod_lpn(nLPN);
#else
	UINT32 mod_lpn = nLPN;
#endif
	META_CACHE_ENTRY*	pstEntry = GetMetaEntry(mod_lpn);

	if (pstEntry == NULL)
	{
		return FALSE;
	}

	return (pstEntry->m_bValid == TRUE) ? TRUE : FALSE;
}

BOOL
META_CACHE::IsMetaWritable(UINT32 nLPN)
{
#if (META_PER_WAY==1)
	UINT32 mod_lpn = get_mod_lpn(nLPN);
#else
	UINT32 mod_lpn = nLPN;
#endif
	META_CACHE_ENTRY*	pstEntry = GetMetaEntry(mod_lpn);

	if (pstEntry == NULL)
	{
		return FALSE;
	}
	if (pstEntry->m_bValid == TRUE && pstEntry->m_bIORunning == FALSE)
		return TRUE;
	else
		return FALSE;
	
}


VOID
META_CACHE::LoadMeta(UINT32 nLPN, UINT32 DS_FLAG)
{
#if (META_PER_WAY==1)
	UINT32 mod_lpn = get_mod_lpn(nLPN);
#else
	UINT32 mod_lpn = nLPN;
#endif
#if (SUPPORT_META_DEMAND_LOADING == 1)
	META_CACHE_ENTRY*	pstEntry = GetMetaEntry(mod_lpn);
	if (pstEntry != NULL)
	{
		DEBUG_ASSERT(pstEntry->m_bIORunning == TRUE);
		DEBUG_ASSERT(pstEntry->m_bValid == FALSE);
//		xil_printf("Im Here\r\n");
		return;
	}

	pstEntry = _Allocate();
	if (pstEntry == NULL)
	{
		// busy
		return;
	}

    // Hash KJH
    pstEntry->m_nMetaLPN = _GetMetaLPN(mod_lpn);
    _HashInsert(pstEntry);
    // Hash KJH

	REQUEST_MGR*	pstRequestMgr = DFTL_GLOBAL::GetRequestMgr();
	META_REQUEST_INFO*	pstRequestInfo = pstRequestMgr->GetMetaRequestInfo();
	META_REQUEST*	pstRequest = pstRequestInfo->AllocateRequest();

	if (pstRequest == NULL)
	{
		_HashRemove(pstEntry); // Hash KJH
		// there is no free request
		list_del_init(&pstEntry->m_dlList);
		_Release(pstEntry);			// Release Meta entry
		return;
	}

//	pstEntry->m_nMetaLPN = _GetMetaLPN(mod_lpn);

	pstRequest->Initialize(META_REQUEST_READ_WAIT, pstEntry->m_nMetaLPN, pstEntry, IOTYPE_META);
#if (META_PER_WAY==1)
	UINT32 channel, way;
	channel = get_channel_from_lpn(pstEntry->m_nMetaLPN);
	way = get_way_from_lpn(pstEntry->m_nMetaLPN);
	pstRequestInfo->AddToWaitQ(pstRequest, channel, way);
#else
	pstRequestInfo->AddToWaitQ(pstRequest);
#endif
	DFTL_IncreaseProfile(Prof_CMT_read);
	pstEntry->m_bIORunning = TRUE;

	if (DS_FLAG)
		DFTL_IncreaseProfile(Prof_Discard_Load_Num);

	META_DEBUG_PRINTF("[META] Load MetaLPN: %d \n\r", pstEntry->m_nMetaLPN);

#else
	ASSERT(0);
#endif
}

UINT32
META_CACHE::GetL2V(UINT32 nLPN)
{
	META_CACHE_ENTRY*		pstEntry;
#if (META_PER_WAY==1)
	UINT32 mod_lpn = get_mod_lpn(nLPN);
#else
	UINT32 mod_lpn = nLPN;
#endif

	pstEntry = GetMetaEntry(mod_lpn);
	if (pstEntry == NULL)
		return INVALID_PPN;

	DEBUG_ASSERT(pstEntry->m_bValid == TRUE);

	UINT32 nOffset = mod_lpn % L2V_PER_META_PAGE;

	return pstEntry->m_anL2V[nOffset];
}

/*
	@brief	set a new VPPN,
	@return	OldVPPN
*/
UINT32
META_CACHE::SetL2V(UINT32 nLPN, UINT32 nVPPN)
{
	META_CACHE_ENTRY*		pstEntry;
#if (META_PER_WAY==1)
	UINT32 mod_lpn = get_mod_lpn(nLPN);
#else
	UINT32 mod_lpn = nLPN;
#endif

	pstEntry = GetMetaEntry(mod_lpn);
	ASSERT(pstEntry != NULL);

	DEBUG_ASSERT(pstEntry->m_bValid == TRUE);

	UINT32 nOffset = mod_lpn % L2V_PER_META_PAGE;

	UINT32 nOldVPPN = pstEntry->m_anL2V[nOffset];

	pstEntry->m_anL2V[nOffset] = nVPPN;

	pstEntry->m_bDirty = TRUE;

	return nOldVPPN;
}

UINT32
META_CACHE::get_mod_lpn(UINT32 nLPN) {
//	UINT32 nChannel = get_channel_from_lpn(nLPN);
//	UINT32 nWay = get_way_from_lpn(nLPN);
//	UINT32 nLBN = get_lbn_from_lpn(nLPN);
//	UINT32 nPage = get_page_from_lpn(nLPN);
//	UINT32 page_offset = nLPN % LPN_PER_PHYSICAL_PAGE;
//	UINT32 mod_lpn = get_mod_lpn_from_lpn_lbn(nChannel, nWay, nLBN, nPage) + page_offset;

	return nLPN;
}

UINT32
META_CACHE::_GetMetaLPN(UINT32 nLPN)
{
	return nLPN / L2V_PER_META_PAGE;
}

VOID
META_CACHE::_Release(META_CACHE_ENTRY* pstEntry)
{
	list_add_head(&pstEntry->m_dlList, &m_dlFree);
	m_nFreeCount++;
}

/*
	@brief	allocate a cache entry
*/

META_CACHE_ENTRY*
META_CACHE::_Allocate(VOID)
{
	META_CACHE_ENTRY*	pstEntry;
	if (m_nFreeCount == 0)
	{
		DEBUG_ASSERT(list_empty(&m_dlFree) == TRUE);
		pstEntry = list_last_entry(&m_dlLRU, META_CACHE_ENTRY, m_dlList);

		if (pstEntry->m_bIORunning == TRUE)
		{
			// Programing on going
			return NULL;
		}

		DEBUG_ASSERT(pstEntry->m_bValid == TRUE);


		if (pstEntry->m_bDirty == TRUE)
		{
			// need to write this entry to NAND flash memory
			// Add To Meta Write Queue
			REQUEST_MGR*	pstRequestMgr = DFTL_GLOBAL::GetRequestMgr();
			META_REQUEST_INFO*	pstRequestInfo = pstRequestMgr->GetMetaRequestInfo();
			META_REQUEST*	pstRequest = pstRequestInfo->AllocateRequest();
			if (pstRequest == NULL)
			{
				// there is no free reuqest
				return NULL;
			}

			pstRequest->Initialize(META_REQUEST_WRITE_WAIT, pstEntry->m_nMetaLPN, pstEntry, IOTYPE_META);

			// copy meta to buffer entry
			OSAL_MEMCPY(pstRequest->GetBuffer()->m_pMainBuf, &pstEntry->m_anL2V[0], META_VPAGE_SIZE);
#if (META_PER_WAY==1)
			UINT32 channel, way;
			channel = get_channel_from_lpn(pstEntry->m_nMetaLPN);
			way = get_way_from_lpn(pstEntry->m_nMetaLPN);
			pstRequestInfo->AddToWaitQ(pstRequest, channel, way);
#else
			pstRequestInfo->AddToWaitQ(pstRequest);
#endif

			DFTL_IncreaseProfile(Prof_CMT_write);
			pstEntry->m_bIORunning = TRUE;

			META_DEBUG_PRINTF("[META] Flush MetaLPN: %d \r\n", pstEntry->m_nMetaLPN);

			return NULL;
		}

		_HashRemove(pstEntry); //Hash KJH

		META_DEBUG_PRINTF("[META] Evicted MetaLPN: %d \r\n", pstEntry->m_nMetaLPN);

		ASSERT(pstEntry->m_bValid == TRUE);
	}
	else
	{
		pstEntry = list_first_entry(&m_dlFree, META_CACHE_ENTRY, m_dlList);
		m_nFreeCount--;
	}

	list_move_head(&pstEntry->m_dlList, &m_dlLRU);

	pstEntry->m_bValid = FALSE;
	ASSERT(pstEntry->m_bDirty == FALSE);
	ASSERT(pstEntry->m_bIORunning == FALSE);

	return pstEntry;
}

// Hash KJH
META_CACHE_ENTRY* META_CACHE::_HashFind(UINT32 nMetaLPN)
{
    UINT32 idx = _HashIdx(nMetaLPN);
    META_CACHE_ENTRY* e;
    list_for_each_entry(META_CACHE_ENTRY, e, &m_ahHash[idx], m_dlHash) {
        if (e->m_nMetaLPN == nMetaLPN) return e;
    }
    return NULL;
}
VOID META_CACHE::_HashInsert(META_CACHE_ENTRY* e)
{
    UINT32 idx = _HashIdx(e->m_nMetaLPN);
    list_add_head(&e->m_dlHash, &m_ahHash[idx]);
}
VOID META_CACHE::_HashRemove(META_CACHE_ENTRY* e)
{
    list_del_init(&e->m_dlHash);
}
// Hash KJH
///////////////////////////////////////////////////////////////////////////////////
//
//	Meta Manager
//
///////////////////////////////////////////////////////////////////////////////////

VOID
META_MGR::Initialize(VOID)
{
	m_stMetaCache.Initialize();
#if (SUPPORT_META_DEMAND_LOADING == 1)
	
#else
	m_panL2V = (UINT32*)OSAL_MemAlloc(MEM_TYPE_FW_DATA, _GetL2PSize(), OSAL_MEMALLOC_FW_ALIGNMENT);
#endif

	m_bFormatted = FALSE;
}

BOOL
META_MGR::Format(VOID)
{
	if (m_bFormatted == TRUE)
	{
		return TRUE;
	}

	BOOL	bRet;

	bRet = m_stMetaCache.Format();
#if (SUPPORT_META_DEMAND_LOADING == 1)
#else
	OSAL_MEMSET(m_panL2V, 0xFF, _GetL2PSize());		// set invalid LPN
	bRet = TRUE;
#endif

	if (bRet == TRUE)
	{
		m_nVPC = 0;
		m_bFormatted = TRUE;
	}

	return bRet;
}

BOOL
META_MGR::IsMetaAvailable(UINT32 nLPN)
{
#if (SUPPORT_META_DEMAND_LOADING == 1)
	return m_stMetaCache.IsMetaAvailable(nLPN);
#else
	return TRUE;
#endif
}

BOOL
META_MGR::IsMetaWritable(UINT32 nLPN)
{
#if (SUPPORT_META_DEMAND_LOADING == 1)
	return m_stMetaCache.IsMetaWritable(nLPN);
#else
	return TRUE;
#endif
}

VOID
META_MGR::LoadMeta(UINT32 nLPN, UINT32 DS_FLAG)
{
#if (SUPPORT_META_DEMAND_LOADING == 1)
	return m_stMetaCache.LoadMeta(nLPN, DS_FLAG);
#else
	return;
#endif
}

VOID
META_MGR::LoadDone(META_CACHE_ENTRY* pstMetaEntry, VOID* pBuf)
{
	DEBUG_ASSERT(FALSE == pstMetaEntry->m_bValid);
	DEBUG_ASSERT(FALSE == pstMetaEntry->m_bDirty);
	DEBUG_ASSERT(TRUE == pstMetaEntry->m_bIORunning);

	pstMetaEntry->m_bIORunning = FALSE;
	pstMetaEntry->m_bDirty = FALSE;
	pstMetaEntry->m_bValid = TRUE;

	OSAL_MEMCPY(&pstMetaEntry->m_anL2V[0], pBuf, META_VPAGE_SIZE);
}

VOID
META_MGR::StoreDone(META_CACHE_ENTRY* pstMetaEntry)
{
	DEBUG_ASSERT(TRUE == pstMetaEntry->m_bValid);
	DEBUG_ASSERT(TRUE == pstMetaEntry->m_bDirty);
	DEBUG_ASSERT(TRUE == pstMetaEntry->m_bIORunning);

	pstMetaEntry->m_bIORunning = FALSE;
	pstMetaEntry->m_bDirty = FALSE;
}

UINT32
META_MGR::GetL2V(UINT32 nLPN)
{
	DEBUG_ASSERT(nLPN < DFTL_GLOBAL::GetInstance()->GetLPNCount());

#if (SUPPORT_META_DEMAND_LOADING == 1)
	return m_stMetaCache.GetL2V(nLPN);
#else
	return	m_panL2V[nLPN];
#endif
}

VOID
META_MGR::SetL2V(UINT32 nLPN, UINT32 nVPPN, UINT32 DS_FLAG)
{
	DEBUG_ASSERT(nLPN < DFTL_GLOBAL::GetInstance()->GetLPNCount());
		
	UINT32	nOldVPPN;

#if (SUPPORT_META_DEMAND_LOADING == 1)
	nOldVPPN = m_stMetaCache.SetL2V(nLPN, nVPPN);
#else
	nOldVPPN = m_panL2V[nLPN];

	m_panL2V[nLPN] = nVPPN;
#endif

	if (nOldVPPN == INVALID_PPN)
	{
		UINT32 nVBN = VBN_FROM_VPPN(nVPPN);
		UINT32 channel = CHANNEL_FROM_VPPN(nVPPN);
		UINT32 way = WAY_FROM_VPPN(nVPPN);
		VBINFO*		pstVBInfo;

		pstVBInfo = DFTL_GLOBAL::GetVBInfoMgr(channel, way)->GetVBInfo(nVBN);
//		pstVBInfo->IncreaseValidate();
		m_nVPC++;
	}
	else
	{
		// Invalidate OLD PPN
		VNAND*	pstVNand = DFTL_GLOBAL::GetVNandMgr();
		DEBUG_ASSERT(pstVNand->GetV2L(nOldVPPN) == nLPN);
		DFTL_GLOBAL::GetInstance()->IncreaseProfileCount(PROFILE_HOST_OVERWRITE);

		pstVNand->Invalidate(nOldVPPN, DS_FLAG);
		DFTL_GLOBAL::GetInstance()->GetUserBlockMgr()->Invalidate(nOldVPPN);

		UINT32 nVBN = VBN_FROM_VPPN(nOldVPPN);
		UINT32 channel = CHANNEL_FROM_VPPN(nOldVPPN);
		UINT32 way = WAY_FROM_VPPN(nOldVPPN);
//		if (nVBN > 19)
//		{
//			int print = DFTL_GLOBAL::GetInstance()->GetUserBlockMgr()->CheckVPC(channel, way, nVBN, 0);
//			if (print == 1)
//				xil_printf("SetL2V Check Result\r\n");//	xil_printf("[VNAND::ProgramPageSimul] nLPN: %u, nVPPN: %u\r\n", nLPN, nVPPN);
//		}
	}
}

/*
@brief	return L2p SIZE IN BYTE
*/
INT32
META_MGR::_GetL2PSize(VOID)
{
	return sizeof(UINT32) * DFTL_GLOBAL::GetInstance()->GetLPNCount();
}

///////////////////////////////////////////////////////////////////////////////////
//
//	Meta L2V Manager
//
///////////////////////////////////////////////////////////////////////////////////

VOID
META_L2V_MGR::Initialize(VOID)
{
	m_panL2V = (UINT32*)OSAL_MemAlloc(MEM_TYPE_FW_DATA, _GetL2PSize(), OSAL_MEMALLOC_FW_ALIGNMENT);

	m_bFormatted = FALSE;
}

BOOL
META_L2V_MGR::Format(VOID)
{
	if (m_bFormatted == TRUE)
	{
		return TRUE;
	}

	OSAL_MEMSET(m_panL2V, 0xFF, _GetL2PSize());		// set invalid LPN

	m_nVPC = 0;
	m_bFormatted = TRUE;

	return TRUE;
}

UINT32
META_L2V_MGR::GetMetaLPNCount(VOID)
{
	UINT32	nLPNCount	= DFTL_GLOBAL::GetInstance()->GetLPNCount();
	return CEIL(((INT32)nLPNCount), (INT32)L2V_PER_META_PAGE);
}

UINT32
META_L2V_MGR::GetL2V(UINT32 nLPN)
{
	DEBUG_ASSERT(nLPN < GetMetaLPNCount());
	return	m_panL2V[nLPN];
}

VOID
META_L2V_MGR::SetL2V(UINT32 nLPN, UINT32 nVPPN)
{
#if (SUPPORT_META_DEMAND_LOADING == 1)
	DEBUG_ASSERT(nLPN < GetMetaLPNCount());

	BOOL	bOverWrite;

	if (m_panL2V[nLPN] != INVALID_PPN)
	{
		// Invalidate OLD PPN
		UINT32 nOldVPPN = m_panL2V[nLPN];
		VNAND*	pstVNand = DFTL_GLOBAL::GetVNandMgr();
		DEBUG_ASSERT(pstVNand->GetV2L(nOldVPPN) == nLPN);

		pstVNand->Invalidate(nOldVPPN, 2);

		DFTL_GLOBAL::GetInstance()->GetMetaBlockMgr()->Invalidate(nOldVPPN);

		bOverWrite = TRUE;
	}
	else
	{
		bOverWrite = FALSE;
	}

	m_panL2V[nLPN] = nVPPN;

	if (bOverWrite == FALSE)
	{
		m_nVPC++;
	}
#else
	ASSERT(0);		// check option
#endif
}

/*
@brief	return L2p SIZE IN BYTE
*/
INT32
META_L2V_MGR::_GetL2PSize(VOID)
{
	return sizeof(UINT32) * GetMetaLPNCount();
}
