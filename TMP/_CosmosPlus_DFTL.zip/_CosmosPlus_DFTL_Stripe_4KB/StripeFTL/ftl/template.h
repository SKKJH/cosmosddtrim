#ifndef __TEMPLATE_H__
#define __TEMPLATE_H__

#endif