/*******************************************************
*
* Copyright (C) 2018-2019
* Embedded Software Laboratory(ESLab), SUNG KYUN KWAN UNIVERSITY
*
* This file is part of ESLab's Flash memory firmware
*
* This source can not be copied and/or distributed without the express
* permission of ESLab
*
* Author: DongYoung Seo (dongyoung.seo@gmail.com)
		  Kyuhwa Han (hgh6877@gmail.com)
* ESLab: http://nyx.skku.ac.kr
*
*******************************************************/

#include "dftl_internal.h"

///////////////////////////////////////////////////////////////////////////////
//
//	VBlock Information
//
///////////////////////////////////////////////////////////////////////////////
VOID VBINFO::IncreaseInvalidate(VOID)
{
	m_nInvalidLPN++;
	DEBUG_ASSERT(m_nInvalidLPN <= DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock());
}

VOID VBINFO::IncreaseValidate(VOID)
{
	m_nValidLPN++;
}

VOID VBINFO::DecreaseValidate(VOID)
{
	m_nValidLPN--;
}

BOOL VBINFO::IsFullInvalid(VOID)
{
	return (m_nInvalidLPN < DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock()) ? FALSE : TRUE;
}

VOID VBINFO::SetFullInvalid(VOID)
{
	m_nInvalidLPN = DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock();
}

///////////////////////////////////////////////////////////////////////////////
//
//	VBlock Information Manager
//
///////////////////////////////////////////////////////////////////////////////
VOID VBINFO_MGR::Initialize(VOID)
{
	INT32 nSize = sizeof(VBINFO) * DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount();
	m_pastVBInfo = (VBINFO *)OSAL_MemAlloc(MEM_TYPE_FW_DATA, nSize, OSAL_MEMALLOC_FW_ALIGNMENT);

	ASSERT(GetVBSize() == (DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock() * LOGICAL_PAGE_SIZE));
}

VOID VBINFO_MGR::Format(VOID)
{
	UINT32 nVBlockCount = DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount();
	INT32 nSize = sizeof(VBINFO) * nVBlockCount;
	OSAL_MEMSET(m_pastVBInfo, 0x00, nSize);

	/*VBINFO*		pstVBInfo;
	BOOL		bBad;
	for (UINT32 i = 0; i < nVBlockCount; i++)
	{
		bBad = DFTL_GLOBAL::GetVNandMgr()->IsBadBlock(i);
		if (bBad == FALSE)
		{
			pstVBInfo = GetVBInfo(i);
			INIT_LIST_HEAD(&pstVBInfo->m_dlList);
			pstVBInfo->m_nVBN = i;

			pstVBInfo->SetFullInvalid();	// to avoid debug assert
		}
	}*/
}

VBINFO *
VBINFO_MGR::GetVBInfo(UINT32 nVBN)
{
	DEBUG_ASSERT(nVBN < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());
	return &m_pastVBInfo[nVBN];
}

/*
	@brief return Size of VirtualBlock (byte)
*/
UINT32
VBINFO_MGR::GetVBSize(VOID)
{
	return ((1 << NAND_ADDR_VBN_SHIFT) * LOGICAL_PAGE_SIZE);
}

///////////////////////////////////////////////////////////////////////////////
//
//	Block Manager
//
///////////////////////////////////////////////////////////////////////////////
VOID BLOCK_MGR::Initialize(BLOCK_MGR_TYPE eType)
{
	for (UINT32 channel = 0; channel < USER_CHANNELS; channel++)
	{
		for (UINT32 way = 0; way < USER_WAYS; way++)
		{
			// Nothing to do
			INIT_LIST_HEAD(&m_dlFreeBlocks[channel][way]);
			m_nFreeBlocks[channel][way] = 0;

			INIT_LIST_HEAD(&m_dlUsedBlocks[channel][way]);
			m_nUsedBlocks[channel][way] = 0;
		}
	}

	m_eType = eType;

	m_bFormatted = FALSE;
}

VOID BLOCK_MGR::_FormatUser(VOID)
{
	UINT32 nVBlockCount = DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount();
	for (UINT32 channel = 0; channel < USER_CHANNELS; channel++)
	{
		for (UINT32 way = 0; way < USER_WAYS; way++)
		{
			VNAND *pstVNandMgr = DFTL_GLOBAL::GetVNandMgr();
			VBINFO_MGR *pstVBInfoMgr = DFTL_GLOBAL::GetVBInfoMgr(channel, way);

			VBINFO *pstVBInfo;
			BOOL bBad;
			for (UINT32 i = 0; i < nVBlockCount; i++)
			{
				pstVBInfo = pstVBInfoMgr->GetVBInfo(i);

				bBad = pstVNandMgr->IsBadBlock(channel, way, i);
				if (bBad == FALSE)
				{
					INIT_LIST_HEAD(&pstVBInfo->m_dlList);
					pstVBInfo->m_nVBN = i;

					pstVBInfo->SetFullInvalid(); // to avoid debug assert
					pstVBInfo->ClearBad();

					m_nUsedBlocks[channel][way]++; // to avoid underflow by release without allocation
					Release(channel, way, i, 0);
				}
				else
				{
					pstVBInfo->SetBad();
					pstVBInfo->ClearUser();
					pstVBInfo->ClearGC();
				}
			}
		}
	}
}

VOID BLOCK_MGR::_FormatMeta(VOID)
{
	META_L2V_MGR *pstMetaL2VMgr = DFTL_GLOBAL::GetMetaL2VMgr();
	UINT32 nMetaVPageCount = pstMetaL2VMgr->GetMetaLPNCount();
	UINT32 nVPagePerVBN = DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock() * USER_CHANNELS * USER_WAYS;
	UINT32 nMetaVBlockCount = CEIL((INT32)nMetaVPageCount, (INT32)nVPagePerVBN) * (1 + META_OP_RATIO);

	nMetaVBlockCount = MAX(nMetaVBlockCount, META_VBLOCK_COUNT_MIN);
	for (UINT32 channel = 0; channel < USER_CHANNELS; channel++)
	{
		for (UINT32 way = 0; way < USER_WAYS; way++)
		{
			VBINFO_MGR *pstVBInfoMgr = DFTL_GLOBAL::GetVBInfoMgr(channel, way);

			// Get blocks from user block
			BLOCK_MGR *pstUserBlockMgr = DFTL_GLOBAL::GetUserBlockMgr();
			UINT32 nVBN;
			VBINFO *pstVBInfo;

			for (UINT32 i = 0; i < nMetaVBlockCount; i++)
			{
				nVBN = pstUserBlockMgr->Allocate(channel, way, TRUE, FALSE, FALSE);

				DEBUG_ASSERT(DFTL_GLOBAL::GetVNandMgr()->IsBadBlock(channel, way, nVBN) == FALSE);

				pstVBInfo = pstVBInfoMgr->GetVBInfo(nVBN);
				list_del_init(&pstVBInfo->m_dlList);

				pstVBInfo->SetFullInvalid(); // to avoid debug assert

				m_nUsedBlocks[channel][way]++; // to avoid underflow by release without allocation
				Release(channel, way, nVBN, 0);
			}
		}
	}
}

VOID BLOCK_MGR::Format(VOID)
{
	if (m_bFormatted == TRUE)
	{
		return;
	}

	if (m_eType == META_BLOCK_MGR)
	{
		_FormatMeta();
	}
	else
	{
		DEBUG_ASSERT(m_eType == USER_BLOCK_MGR);
		_FormatUser();
	}

	m_bFormatted = TRUE;
}

UINT32
BLOCK_MGR::Allocate(UINT32 channel, UINT32 way, BOOL bUser, BOOL bGC, BOOL bMeta)
{
	DEBUG_ASSERT(m_nFreeBlocks[channel][way] > 0);
	DEBUG_ASSERT(m_nUsedBlocks[channel][way] < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());
	DEBUG_ASSERT((bMeta == TRUE) ? (m_eType == META_BLOCK_MGR) : TRUE);

	VBINFO *pstVBInfo = list_first_entry(&m_dlFreeBlocks[channel][way], VBINFO, m_dlList);

	list_del_init(&pstVBInfo->m_dlList);
	list_add_tail(&pstVBInfo->m_dlList, &m_dlUsedBlocks[channel][way]);

	pstVBInfo->ClearFree();
	pstVBInfo->ClearUser();
	pstVBInfo->ClearGC();
	pstVBInfo->ClearMeta();

	if (bUser == TRUE)
	{
		pstVBInfo->INIT = 0;
		pstVBInfo->SetUser();
	}
	else if (bGC == TRUE)
	{
		pstVBInfo->SetGC();
	}
	else if (bMeta == TRUE)
	{
		pstVBInfo->SetMeta();
	}
	else
	{
		ASSERT(0);
	}

	pstVBInfo->SetActive();
	pstVBInfo->SetInvalidPageCount(0);
	pstVBInfo->SetValidPageCount(0);

	m_nFreeBlocks[channel][way]--;
	m_nUsedBlocks[channel][way]++;

	return pstVBInfo->m_nVBN;
}

VOID BLOCK_MGR::Release(UINT32 channel, UINT32 way, UINT32 nVBN, UINT32 FLAG)
{
	DEBUG_ASSERT(nVBN < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());
	DEBUG_ASSERT(m_nUsedBlocks[channel][way] > 0);
	DEBUG_ASSERT(m_nFreeBlocks[channel][way] < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());

	VBINFO *pstVBInfo;

	pstVBInfo = DFTL_GLOBAL::GetVBInfoMgr(channel, way)->GetVBInfo(nVBN);

	DEBUG_ASSERT(pstVBInfo->IsFullInvalid() == TRUE);

	pstVBInfo->SetFree();
	pstVBInfo->INIT = 0;
	//	pstVBInfo->ClearActive();
	//	pstVBInfo->ClearUser();
	//	pstVBInfo->ClearGC();
	//	pstVBInfo->ClearMeta();

	list_del_init(&pstVBInfo->m_dlList);
	m_nUsedBlocks[channel][way]--;

	// Add to free block list
	list_add_tail(&pstVBInfo->m_dlList, &m_dlFreeBlocks[channel][way]);
	m_nFreeBlocks[channel][way]++;

	if ((FLAG == 1) && !pstVBInfo->IsMeta())
	{
//		xil_printf("	[Release] VBN:%u, CH:%u, WY:%u\r\n", nVBN, channel, way);
	}
}

VOID BLOCK_MGR::Invalidate(UINT32 nVPPN)
{
	UINT32 nVBN = VBN_FROM_VPPN(nVPPN);
	UINT32 channel = CHANNEL_FROM_VPPN(nVPPN);
	UINT32 way = WAY_FROM_VPPN(nVPPN);

	DEBUG_ASSERT(nVBN < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());

	VBINFO *pstVBInfo;
	pstVBInfo = DFTL_GLOBAL::GetVBInfoMgr(channel, way)->GetVBInfo(nVBN);

	pstVBInfo->IncreaseInvalidate();
	pstVBInfo->DecreaseValidate();

	if (pstVBInfo->IsFullInvalid() == TRUE)
	{
		// Release block
		Release(channel, way, nVBN, 1);

		DFTL_GLOBAL::GetInstance()->IncreaseProfileCount(PROFILE_FULL_INVALID_BLOCK, 1);
	}
}

UINT32
BLOCK_MGR::VPC_Count(UINT32 channel, UINT32 way, UINT32 nVBN, UINT32 FLAG)
{
	VNAND *pstVNandMgr = DFTL_GLOBAL::GetVNandMgr();
	UINT32 nValidVPN_VNand = pstVNandMgr->GetValidVPNCount(channel, way, nVBN);

	return nValidVPN_VNand;
}

UINT32
BLOCK_MGR::CheckVPC(UINT32 channel, UINT32 way, UINT32 nVBN, UINT32 FLAG)
{
	DEBUG_ASSERT(nVBN < DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount());

	VBINFO *pstVBInfo;
	pstVBInfo = DFTL_GLOBAL::GetVBInfoMgr(channel, way)->GetVBInfo(nVBN);

	UINT32 nValidVPN_VBInfo;

	nValidVPN_VBInfo = DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock() - pstVBInfo->GetInvalidLPNCount();

	VNAND *pstVNandMgr = DFTL_GLOBAL::GetVNandMgr();
	UINT32 nValidVPN_VNand = pstVNandMgr->GetValidVPNCount(channel, way, nVBN);

	//	DEBUG_ASSERT(nValidVPN_VBInfo == nValidVPN_VNand);
	if (nValidVPN_VBInfo != nValidVPN_VNand)
	{
		xil_printf("[UNMATCHED] [%u, %u, %u], ", channel, way, nVBN);
		xil_printf("Valid CNT :%u, NAND BIT :%u\r\n", nValidVPN_VBInfo, nValidVPN_VNand);
		return 1;
	}
	else
	{
		if (FLAG == 1)
		{
			xil_printf("[MATCHED] [%u, %u, %u], ", channel, way, nVBN);
			xil_printf("Valid CNT :%u, NAND BIT :%u\r\n", nValidVPN_VBInfo, nValidVPN_VNand);
		}
	}
	return 0;
}

VOID BLOCK_MGR::INIT_CVPC(UINT32 channel, UINT32 way, UINT32 nVBN)
{
	VBINFO *pstVBInfo;
	pstVBInfo = DFTL_GLOBAL::GetVBInfoMgr(channel, way)->GetVBInfo(nVBN);
	pstVBInfo->INIT = 1;
}

static inline void _print_vb_line_state(const VBINFO *vb, UINT32 ch, UINT32 wy, UINT32 vppb)
{
	const UINT32 inv = vb->GetInvalidLPNCount();
	const UINT32 val = vb->GetValidLPNCount();
	if (!vb->IsBad() && !vb->IsMeta())
		if (!vb->IsFree())
		{
			PRINTF("    VBN=%u inv=%u/%u val=%u/%u ch=%u wy=%u [%s%s%s]\r\n",
				   vb->m_nVBN, inv, vppb, val, vppb, ch, wy,
				   vb->IsActive() ? "A" : "",
				   vb->IsMeta() ? " M" : "",
				   vb->IsFree() ? " F" : "");
		}
}

VOID BLOCK_MGR::DebugPrintAllByVBN_CW(UINT32 channel, UINT32 way, UINT32 FLAG) const
{
	const UINT32 vblk_cnt = DFTL_GLOBAL::GetVNandMgr()->GetVBlockCount();
	const UINT32 vppb = DFTL_GLOBAL::GetInstance()->GetVPagePerVBlock();

	VBINFO_MGR *vbmgr = DFTL_GLOBAL::GetVBInfoMgr(channel, way);

	if (FLAG == 1)
	{
		PRINTF("=== Block States [CH=%u, WAY=%u] ===\r\n", channel, way);

		for (UINT32 vbn = 0; vbn < vblk_cnt; ++vbn)
		{
			const VBINFO *vb = vbmgr->GetVBInfo(vbn);
			_print_vb_line_state(vb, channel, way, vppb);
		}
	}

	PRINTF("[%u/%u] SUMMARY: free=%u (used approx=%u)\r\n\n",
		   channel, way, m_nFreeBlocks[channel][way],
		   vblk_cnt - m_nFreeBlocks[channel][way]);
}

VOID BLOCK_MGR::DebugPrintAllByVBN(UINT32 FLAG) const
{
	for (UINT32 ch = 0; ch < USER_CHANNELS; ++ch)
	{
		for (UINT32 wy = 0; wy < USER_WAYS; ++wy)
		{
			DebugPrintAllByVBN_CW(ch, wy, FLAG);
		}
	}
}
