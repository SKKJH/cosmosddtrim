/*******************************************************
*
* Copyright (C) 2018-2019
* Embedded Software Laboratory(ESLab), SUNG KYUN KWAN UNIVERSITY
*
* This file is part of ESLab's Flash memory firmware
*
* This source can not be copied and/or distributed without the express
* permission of ESLab
*
* Author: Kyuhwa Han (hgh6877@gmail.com)
* ESLab: http://nyx.skku.ac.kr
*
*******************************************************/

#include "dftl_internal.h"


VOID DFTL_Profile_Initialize() {
	for (int iter = 0; iter < Prof_Total_Num; iter++) {
		DFTL_profile[iter] = 0;
	}
}

VOID DFTL_IncreaseProfile(DFTL_PROFILE offset) {
	DFTL_profile[(UINT32)offset]++;
}

VOID DFTL_IncreaseProfile(DFTL_PROFILE offset, UINT32 count) {
	DFTL_profile[(UINT32)offset] += count;
}

UINT32 DFTL_GetProfile(DFTL_PROFILE offset) {
	return DFTL_profile[(UINT32)offset];
}

#include "dftl_profile.h"
#include "xil_printf.h"

VOID DFTL_PrintProfile(UINT32 FLAG)
{
	const char* profile_names[] = {
			"Prof_Host_read",
			"Prof_Host_write",
			"Prof_Host_Discard",

			"Prof_CMT_read",
			"Prof_CMT_write",

			"Prof_CMTGC_read",
			"Prof_CMTGC_write",
			"Prof_CMTGC_count",

			"Prof_GC_read",
			"Prof_GC_write",
			"Prof_GC_count",	//2MB block

			"Prof_NAND_read",	//16KB
			"Prof_NAND_write",	//16KB

			"Prof_NAND_HOST_write",
			"Prof_NAND_META_write",
			"Prof_NAND_GC_write",

			"Prof_NAND_CMT_write",
			"Prof_NAND_HG_write",
			"Prof_NAND_erase",

			"Prof_Discard_Range_Num",
			"Prof_Discard_Total_Page_Num",

			"Prof_Discard_Page_Num",
			"Prof_Discard_Pass_Num",
			"Prof_Discard_Load_Num",

			"Prof_Discard_Page_Miss",
			"Prof_Discard_Page_Hit",
	};

	for (UINT32 i = 0; i < Prof_Total_Num; i++) {
		xil_printf("[%-35s] %u\r\n", profile_names[i], DFTL_profile[i]);
		DFTL_profile[i] = 0;
	}
	DFTL_GLOBAL::GetInstance()->DebugBlockPrint(1);
}
