/*******************************************************
*
* Copyright (C) 2018-2019 
* Embedded Software Laboratory(ESLab), SUNG KYUN KWAN UNIVERSITY
* 
* This file is part of ESLab's Flash memory firmware
* 
* This source can not be copied and/or distributed without the express
* permission of ESLab
*
* Author: DongYoung Seo (dongyoung.seo@gmail.com)
		  Kyuhwa Han (hgh6877@gmail.com)
* ESLab: http://nyx.skku.ac.kr
*
*******************************************************/

#ifndef __DFTL_GARBAGECOLLECTOR_H__
#define __DFTL_GARBAGECOLLECTOR_H__

#include "dftl_internal.h"

class GC_POLICY_GREEDY
{
public:
	VOID Initialize(IOTYPE eIOType);
	UINT32 GetVictimVBN(UINT32 channel, UINT32 way);

protected:
	BLOCK_MGR*	m_pstBlockMgr;


private:
};

class GC_DEBUG
{
public:
	typedef enum
	{
		GC_DEBUG_FLAG_READ			= 0x01,
		GC_DEBUG_FLAG_READ_DONE		= 0x02,
		GC_DEBUG_FLAG_WRITE_ISSUE	= 0x04,
		GC_DEBUG_FLAG_WRITE_DONE	= 0x08,
		GC_DEBUG_FLAG_MASK			= 0x0F,
	} GC_DEBUG_FLAG;

	GC_DEBUG() :m_apstVPNStatus(NULL) {};

	VOID Initialize(VOID);
	VOID SetFlag(UINT32 nVPPN, GC_DEBUG_FLAG eFlag);

	GC_DEBUG_FLAG*	m_apstVPNStatus;
	UINT32			m_nRead;
	UINT32			m_nWrite;
};

class GC_MGR : public GC_POLICY_GREEDY
{
public:
	GC_MGR() : m_nVictimVBN(INVALID_VBN) {};

	VOID Initialize(UINT32 nGCTh, IOTYPE eIOType, UINT32 channel, UINT32 way);

	VOID Run(VOID);

	BOOL IsGCRunning(VOID);

	VOID CheckAndStartGC(VOID);

	VOID IncreaseWriteCount(VOID);

	VOID IncreaseIssuedCount(VOID);

	INT32 return_VPC(VOID) {return m_nVPC;}

	UINT32 return_READ(VOID) {return m_nCurReadVPageOffset;}

	UINT32 return_ISSUE(VOID) {return m_nIssuedCount;}

	INT32 return_WRITE(VOID) {return m_nWriteCount;}

	INT32 return_VBN(VOID) {return m_nVictimVBN;}

#if (SUPPORT_GC_DEBUG == 1)
	GC_DEBUG	m_stDebug;
#endif

private:
	VOID _Read(VOID);
public:
	UINT32		m_nThreshold;
	IOTYPE		m_eIOType;

	// A block GC will be done on the below condition
	// 1. when nCurReadOffset offset goes up to the end of page.
	// 2. nReadLPNCount == m_nWriteIssuedLPNCount		<== Write issue done

	INT32	m_nVictimVBN;			// Victim block
	INT32	m_nVPC;					// Valid Page count of VBN @ GC start
	INT32	m_nVCNT;					// Valid Page count of VBN @ GC start
	UINT32	m_nCurReadVPageOffset;	// Read logical page offset
	UINT32	m_nIssuedCount;
	INT32	m_nWriteCount;	// count of write issued LPN
	UINT32 m_channel;
	UINT32 m_way;
};

//SUPER_GC_MGR
class SUPER_GC_MGR
{
public:
	VOID Initialize(VOID);

	BOOL IsGCRunning(VOID);

	VOID CheckAndStartGC(VOID);

	UINT32 GetVictimVBN(VOID);

	INT32 return_VBN(VOID) {return m_nVictimVBN;}

	UINT32		m_nThreshold;

	INT32	m_nVictimVBN;			// Victim block
	INT32	m_nGCCnt;

	INT32	ch_0_wy_0;
	INT32	ch_0_wy_1;
	INT32	ch_1_wy_0;
	INT32	ch_1_wy_1;
};
#endif
